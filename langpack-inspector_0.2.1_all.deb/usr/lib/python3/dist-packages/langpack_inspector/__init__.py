"""Language Pack Inspector - GTK4/Adwaita app for inspecting Ubuntu language packs."""

__version__ = "0.1.0"
__app_id__ = "se.danielnylander.LangpackInspector"
